# Crop Avatar

A complete example of Cropper.


## Server Dependencies

- PHP 5.5+


## Browser Support

- Chrome 38+
- Firefox 33+
- Internet Explorer 8+
- Opera 25+
- Safari 5.1+
